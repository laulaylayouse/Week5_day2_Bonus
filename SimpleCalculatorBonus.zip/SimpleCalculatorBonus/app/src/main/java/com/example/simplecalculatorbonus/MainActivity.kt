package com.example.simplecalculatorbonus

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var EditText_num1:EditText
    lateinit var EditText_num2: EditText
    lateinit var Button_Add: Button
    lateinit var Button_subtract:Button
    lateinit var Button_Multiply:Button
    lateinit var Button_divide:Button
    lateinit var Button_Clear:Button
    lateinit var TextView_Result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        TextView_Result=findViewById(R.id.TextView_Result)

        EditText_num1=findViewById(R.id.EditText_num1)
        EditText_num2=findViewById(R.id.EditText_num2)

        Button_Add=findViewById(R.id.Button_Add)
        Button_subtract=findViewById(R.id.Button_subtract)
        Button_Multiply=findViewById(R.id.Button_Multiply)
        Button_divide=findViewById(R.id.Button_divide)
        Button_Clear = findViewById(R.id.Button_Clear)

        Button_Add.setOnClickListener { checkIfEmpty(1) }
        Button_subtract.setOnClickListener { checkIfEmpty(2) }
        Button_Multiply.setOnClickListener { checkIfEmpty(3) }
        Button_divide.setOnClickListener { checkIfEmpty(4) }
        Button_Clear.setOnClickListener { checkIfEmpty(5) }

    }

    fun checkIfEmpty(check:Int){
        val number1= EditText_num1.text.toString()
        val number2= EditText_num2.text.toString()

        if(number1.isNotEmpty() && number2.isNotEmpty()){
            val num1 = number1.toFloat()
            val num2 = number2.toFloat()
            when(check){
                1 -> {

                    EditText_num1.setText("")
                    EditText_num2.setText("")
                    TextView_Result.setText("The Result:\n $num1+$num2 = ${num1+num2}")
                }
                2 -> {

                    EditText_num1.setText("")
                    EditText_num2.setText("")
                    TextView_Result.setText("The Result:\n $num1 - $num2 = ${num1-num2}")

                }
                3 -> {

                    EditText_num1.setText("")
                    EditText_num2.setText("")
                    TextView_Result.setText("The Result:\n $num1 X $num2 = ${num1-num2}")

                }
                4 -> {
                    EditText_num1.setText("")
                    EditText_num2.setText("")
                    TextView_Result.setText("The Result:\n $num1 / $num2 = ${num1/num2}")
                }
                5 -> {
                    EditText_num1.setText("")
                    EditText_num2.setText("")
                    TextView_Result.setText("")
                }
            }

        }else{
            if (number1.isEmpty()) {
                Toast.makeText(this, "Please Enter number 1.", Toast.LENGTH_SHORT).show()
            }
            else if (number2.isEmpty()) {
                Toast.makeText(this, "Please Enter number 2.", Toast.LENGTH_SHORT).show()
            }
            else if (number1.isEmpty() && number2.isEmpty()) {
                Toast.makeText(this, "Please Enter Both numbers.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}