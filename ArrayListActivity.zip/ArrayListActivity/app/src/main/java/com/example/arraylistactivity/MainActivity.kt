package com.example.arraylistactivity

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var EditText_Name: EditText
    lateinit var Button_Add: Button

    lateinit var EditText_Get: EditText
    lateinit var Button_Get: Button

    lateinit var TextView: TextView

    val names = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        EditText_Name = findViewById(R.id.EditText_Name)
        Button_Add = findViewById(R.id.Button_Add)

        EditText_Get = findViewById(R.id.EditText_Get)
        Button_Get = findViewById(R.id.Button_Get)

        TextView = findViewById(R.id.TextView)

        Button_Add.setOnClickListener {
            val name = EditText_Name.text.toString()
            EditText_Name.setText("")
            if (name.isEmpty()) {

                Toast.makeText(this, "Please Enter a Name!!", Toast.LENGTH_SHORT).show()
            }
            else {

                names.add(name)
                Toast.makeText(this, "A Name is Added", Toast.LENGTH_SHORT).show()
            }
        }

        Button_Get.setOnClickListener {
            val index = EditText_Get.text.toString()
            EditText_Get.setText("")
            if (index.isNotEmpty()) {
                val number = index.toInt() - 1
                try {
                    TextView.setText(names[number])
                } catch (e: Exception) {
                    Toast.makeText(this, "No Name with this index found!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please Enter an index Number!!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}