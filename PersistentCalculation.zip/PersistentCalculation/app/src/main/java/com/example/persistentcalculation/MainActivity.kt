package com.example.persistentcalculation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var EditText_num1:EditText
    lateinit var EditText_num2: EditText
    lateinit var Button_Multiply: Button
    lateinit var TextView_Result: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        EditText_num1 = findViewById(R.id.EditText_num1)
        EditText_num2 = findViewById(R.id.EditText_num2)
        Button_Multiply = findViewById(R.id.Button_Multiply)
        TextView_Result = findViewById(R.id.TextView_Result)

        Button_Multiply.setOnClickListener {

            val number1 = EditText_num1.text.toString().toDouble()
            val number2 = EditText_num2.text.toString().toFloat()

            EditText_num1.setText("")
            EditText_num2.setText("")
            val result = (number1 * number2).toString()
            TextView_Result.setText("The Result is: $result")
        }
    }

}